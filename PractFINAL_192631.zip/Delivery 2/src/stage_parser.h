#ifndef _STAGE_PARSER_H_
#define _STAGE_PARSER_H_

#include <string>
#include <fstream>
#include <unordered_map>
#include "stage.h"

// To do: reformatting
void parse_stage(sStage* to_fill, std::string file_name);

#endif